echo "test" > /etc/nginx/haha

