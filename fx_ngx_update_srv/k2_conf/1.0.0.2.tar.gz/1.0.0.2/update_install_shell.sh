cp -rf ./nginx.conf /etc/nginx/nginx.conf22
echo "test" > /etc/nginx/haha

